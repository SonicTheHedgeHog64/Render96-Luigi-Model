extern const GeoLayout luigis_metal_cap_001_switch_opt1[];
extern const GeoLayout luigis_metal_cap_geo[];
extern Lights1 luigis_metal_cap_luigi_metal_lights;
extern u8 luigis_metal_cap_metaltest_rgba16[];
extern Vtx luigis_metal_cap_000_displaylist_mesh_layer_1_vtx_0[554];
extern Gfx luigis_metal_cap_000_displaylist_mesh_layer_1_tri_0[];
extern Gfx mat_luigis_metal_cap_luigi_metal[];
extern Gfx mat_revert_luigis_metal_cap_luigi_metal[];
extern Gfx luigis_metal_cap_000_displaylist_mesh_layer_1[];
