extern const struct Animation *const luigi_anims[];
#include "anims/table_enum.h"
