#include "table_enum.h"
const struct Animation *const luigi_anims[] = {
	&anim_C3,
	&anim_C4,
	&anim_C5,
	&anim_72,
	&anim_73,
	&anim_4C,
	NULL,
};
